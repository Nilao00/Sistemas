﻿<?php require_once('../Connections/sistema.php'); ?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');

// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("../");

// Make unified connection variable
$conn_sistema = new KT_connection($sistema, $database_sistema);

//start Trigger_CheckPasswords trigger
//remove this line if you want to edit the code by hand
function Trigger_CheckPasswords(&$tNG) {
  $myThrowError = new tNG_ThrowError($tNG);
  $myThrowError->setErrorMsg("Passwords do not match.");
  $myThrowError->setField("adm_senha");
  $myThrowError->setFieldErrorMsg("The two passwords do not match.");
  return $myThrowError->Execute();
}
//end Trigger_CheckPasswords trigger

//start Trigger_WelcomeEmail trigger
//remove this line if you want to edit the code by hand
function Trigger_WelcomeEmail(&$tNG) {
  $emailObj = new tNG_Email($tNG);
  $emailObj->setFrom("{KT_defaultSender}");
  $emailObj->setTo("{adm_email}");
  $emailObj->setCC("");
  $emailObj->setBCC("");
  $emailObj->setSubject("Welcome");
  //FromFile method
  $emailObj->setContentFile("../includes/mailtemplates/welcome.html");
  $emailObj->setEncoding("ISO-8859-1");
  $emailObj->setFormat("HTML/Text");
  $emailObj->setImportance("Normal");
  return $emailObj->Execute();
}
//end Trigger_WelcomeEmail trigger

//start Trigger_ActivationEmail trigger
//remove this line if you want to edit the code by hand
function Trigger_ActivationEmail(&$tNG) {
  $emailObj = new tNG_Email($tNG);
  $emailObj->setFrom("{KT_defaultSender}");
  $emailObj->setTo("{adm_email}");
  $emailObj->setCC("");
  $emailObj->setBCC("");
  $emailObj->setSubject("Activation");
  //FromFile method
  $emailObj->setContentFile("../includes/mailtemplates/activate.html");
  $emailObj->setEncoding("ISO-8859-1");
  $emailObj->setFormat("HTML/Text");
  $emailObj->setImportance("Normal");
  return $emailObj->Execute();
}
//end Trigger_ActivationEmail trigger

// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("adm_login", true, "text", "", "", "", "Crie o seu login");
$formValidation->addField("adm_senha", true, "text", "", "", "", "digite a senha");
$formValidation->addField("adm_email", true, "text", "email", "", "", "digite o seu e-mail");
$tNGs->prepareValidation($formValidation);
// End trigger

// Make an insert transaction instance
$userRegistration = new tNG_insert($conn_sistema);
$tNGs->addTransaction($userRegistration);
// Register triggers
$userRegistration->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$userRegistration->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$userRegistration->registerTrigger("END", "Trigger_Default_Redirect", 99, "{kt_login_redirect}");
$userRegistration->registerConditionalTrigger("{POST.adm_senha} != {POST.re_adm_senha}", "BEFORE", "Trigger_CheckPasswords", 50);
$userRegistration->registerTrigger("AFTER", "Trigger_WelcomeEmail", 40);
$userRegistration->registerTrigger("AFTER", "Trigger_ActivationEmail", 40);
// Add columns
$userRegistration->setTable("tb_adm");
$userRegistration->addColumn("adm_login", "STRING_TYPE", "POST", "adm_login");
$userRegistration->addColumn("adm_senha", "STRING_TYPE", "POST", "adm_senha");
$userRegistration->addColumn("adm_nome", "STRING_TYPE", "POST", "adm_nome");
$userRegistration->addColumn("adm_email", "STRING_TYPE", "POST", "adm_email");
$userRegistration->setPrimaryKey("adm_id", "NUMERIC_TYPE");

// Execute all the registered transactions
$tNGs->executeTransactions();

// Get the transaction recordset
$rstb_adm = $tNGs->getRecordset("tb_adm");
$row_rstb_adm = mysql_fetch_assoc($rstb_adm);
$totalRows_rstb_adm = mysql_num_rows($rstb_adm);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sem título</title>
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<?php echo $tNGs->displayValidationRules();?>
</head>

<body>
<form method="post" id="form1" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>">
  <table cellpadding="2" cellspacing="0" class="KT_tngtable">
    <tr>
      <td class="KT_th"><label for="adm_login">Adm_login:</label></td>
      <td><input type="text" name="adm_login" id="adm_login" value="<?php echo KT_escapeAttribute($row_rstb_adm['adm_login']); ?>" size="32" />
        <?php echo $tNGs->displayFieldHint("adm_login");?> <?php echo $tNGs->displayFieldError("tb_adm", "adm_login"); ?></td>
    </tr>
    <tr>
      <td class="KT_th"><label for="adm_senha">Adm_senha:</label></td>
      <td><input type="password" name="adm_senha" id="adm_senha" value="" size="32" />
        <?php echo $tNGs->displayFieldHint("adm_senha");?> <?php echo $tNGs->displayFieldError("tb_adm", "adm_senha"); ?></td>
    </tr>
    <tr>
      <td class="KT_th"><label for="re_adm_senha">Re-type Adm_senha:</label></td>
      <td><input type="password" name="re_adm_senha" id="re_adm_senha" value="" size="32" /></td>
    </tr>
    <tr>
      <td class="KT_th"><label for="adm_nome">Adm_nome:</label></td>
      <td><input type="text" name="adm_nome" id="adm_nome" value="<?php echo KT_escapeAttribute($row_rstb_adm['adm_nome']); ?>" size="32" />
        <?php echo $tNGs->displayFieldHint("adm_nome");?> <?php echo $tNGs->displayFieldError("tb_adm", "adm_nome"); ?></td>
    </tr>
    <tr>
      <td class="KT_th"><label for="adm_email">Adm_email:</label></td>
      <td><input type="text" name="adm_email" id="adm_email" value="<?php echo KT_escapeAttribute($row_rstb_adm['adm_email']); ?>" size="32" />
        <?php echo $tNGs->displayFieldHint("adm_email");?> <?php echo $tNGs->displayFieldError("tb_adm", "adm_email"); ?></td>
    </tr>
    <tr class="KT_buttons">
      <td colspan="2"><input type="submit" name="KT_Insert1" id="KT_Insert1" value="Register" /></td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
</body>
</html>
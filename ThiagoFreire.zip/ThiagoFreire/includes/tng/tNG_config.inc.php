<?php
// Array definitions
  $tNG_login_config = array();
  $tNG_login_config_session = array();
  $tNG_login_config_redirect_success  = array();
  $tNG_login_config_redirect_failed  = array();
  $tNG_login_config_redirect_success = array();
  $tNG_login_config_redirect_failed = array();

// Start Variable definitions
  $tNG_debug_mode = "DEVELOPMENT";
  $tNG_debug_log_type = "";
  $tNG_debug_email_to = "you@yoursite.com";
  $tNG_debug_email_subject = "[BUG] The site went down";
  $tNG_debug_email_from = "webserver@yoursite.com";
  $tNG_email_host = "mail.kikoweb.com";
  $tNG_email_user = "kiko@kikoweb.com";
  $tNG_email_port = "26";
  $tNG_email_password = "P@ssw0rdti@";
  $tNG_email_defaultFrom = "kiko@kikoweb.com";
  $tNG_login_config["connection"] = "sistema";
  $tNG_login_config["table"] = "tb_adm";
  $tNG_login_config["pk_field"] = "adm_id";
  $tNG_login_config["pk_type"] = "NUMERIC_TYPE";
  $tNG_login_config["email_field"] = "adm_email";
  $tNG_login_config["user_field"] = "adm_login";
  $tNG_login_config["password_field"] = "adm_senha";
  $tNG_login_config["level_field"] = "adm_level";
  $tNG_login_config["level_type"] = "STRING_TYPE";
  $tNG_login_config["randomkey_field"] = "";
  $tNG_login_config["activation_field"] = "adm_active";
  $tNG_login_config["password_encrypt"] = "true";
  $tNG_login_config["autologin_expires"] = "30";
  $tNG_login_config["redirect_failed"] = "index.php";
  $tNG_login_config["redirect_success"] = "logado.php";
  $tNG_login_config["login_page"] = "index.php";
  $tNG_login_config["max_tries"] = "3";
  $tNG_login_config["max_tries_field"] = "rest_login_attempts";
  $tNG_login_config["max_tries_disableinterval"] = "5";
  $tNG_login_config["max_tries_disabledate_field"] = "rest_login_attempts";
  $tNG_login_config["registration_date_field"] = "";
  $tNG_login_config["expiration_interval_field"] = "";
  $tNG_login_config["expiration_interval_default"] = "";
  $tNG_login_config["logger_pk"] = "hist_id";
  $tNG_login_config["logger_table"] = "tb_historico";
  $tNG_login_config["logger_user_id"] = "hist_iduser";
  $tNG_login_config["logger_ip"] = "hist_ip";
  $tNG_login_config["logger_datein"] = "hist_login";
  $tNG_login_config["logger_datelastactivity"] = "hist_last_active";
  $tNG_login_config["logger_session"] = "hist_sensao";
  $tNG_login_config_redirect_success["1"] = "adm/logado.php";
  $tNG_login_config_redirect_failed["1"] = "adm/index.php";
  $tNG_login_config_session["kt_login_id"] = "adm_id";
  $tNG_login_config_session["kt_login_user"] = "adm_login";
  $tNG_login_config_session["kt_login_level"] = "adm_level";
  $tNG_login_config_session["kt_adm_nome"] = "adm_nome";
  $tNG_login_config_session["kt_adm_email"] = "adm_email";
// End Variable definitions
?>